let cloudOneX = 50;
let lineXone = 0;
let lineYone = 0;
function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('black');
  frameRate(15); 
  
   let base = 3;

  // Top-left.
  let d = pow(base, 1);
  circle(10, 10, d);

  // Left-center.
  d = pow(base, 2);
  circle(20, 20, d);

  // Right-center.
  d = pow(base, 3);
  circle(40, 40, d);

  // Bottom-right.
  d = pow(base, 4);
  circle(80, 80, d);
  
  let x1 = 10;
  let y1 = 50;
  let x2 = 90;
  let y2 = 50;

  line(x1, y1, x2, y2);
  strokeWeight(5);
  point(x1, y1);
  point(x2, y2);


  textAlign(CENTER);
  textSize(16);

  text(d, 43, 40);
  
  stroke("yellow");
  line(lineXone, lineYone, lineXone + 30, lineYone - 30);
  fill(255);
  stroke(0);
  circle(350, 50, 100);

  stroke("black");   
  fill("black");
  circle(320,50,100);

  stroke(0);
  fill(60);
  triangle(-40,300,65,100, 200,300);
  triangle(120,300,300,200, 400,300);

  fill('rgb(50,56,50)');
  rect(0,300, 400, 100);
  
   fill("rgb(118,100,100)");
  rect(40, 270, 15, 50);

  fill("green");
  triangle(25, 270, 45, 240 - frameCount % 2900,70, 270);
  
  fill(255);
ellipse(cloudOneX, 50, 90, 40);
  ellipse(cloudOneX - 40, 100, 60, 20);
  ellipse(cloudOneX + 20, 150, 40, 10);
  
  cloudOneX = frameCount % width
   lineXone = random(0, width);
  lineYone = random(0, height/2); 
  fill(255)
  text(`mouseX: ${mouseX}, mouseY: ${mouseY}`, 20, 20);  
}