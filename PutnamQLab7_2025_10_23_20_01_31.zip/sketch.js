let riders = ["W(Double)", "OOO", "Fourze", "Wizard", "Gaim", "Drive","Ghost", "Ex-Aid", "Build"];
let myRiders = [];
let myRidersX = [];
let myRidersY = [];

function setup() {
  createCanvas(400, 400);
  background(220);
  for (let p = 0; p<5; p++){
    let num = Math.floor(random(0,riders.length));
    console.log(num);
    myRiders.push(riders[num]);
    riders.splice(num,1);
    myRidersX.push(random(10,width-50));
    myRidersY.push(random(10,height-50));
  }
  console.log(myRiders);
  for (let n = 0; n<myRiders.length; n++){
    text(myRiders[n],myRidersX[n],myRidersY[n]);    
  }
  text("The remaining Neo-Heisei Riders are: "+riders,50,360);
  text("The number of remaining Neo-Heisei Riders: "+riders.length,50,380);
}