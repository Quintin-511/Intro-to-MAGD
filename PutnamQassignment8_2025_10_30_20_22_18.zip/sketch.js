function preload(){
  img = loadImage('putnamqlab2/BLD-MerryChristmas_Form.webp')//"Kamen Rider Build in a special holiday form pulled from the wiki."
  img2 = loadImage('putnamqlab2/KREAl1_Christmas.webp')//"Kamen Rider Ex-Aid in a special holiday form pulled from the wiki."
}
function setup() {
  createCanvas(400, 400);
  textFont('Helvetica')
  text('HAPPY HOLIDAYS!', 375, 200)
}

function draw() {
  background(220);
  image(img, 100, 200);
  image(img2, 300, 200);
}