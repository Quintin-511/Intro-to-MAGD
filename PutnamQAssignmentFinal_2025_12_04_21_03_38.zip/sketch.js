const W = 500;

const bmw = new BMWalker();

function setup() {
  createCanvas(W, W);
}

function draw() {
  background(10);
  translate(W / 2, W / 2);

  const walkerHeight = 300;
  const markers = bmw.getMarkers(walkerHeight);

  markers.forEach((m) => {
    square(m.x, m.y, 10);
  
  });
}